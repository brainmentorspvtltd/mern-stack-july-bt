import { useState } from "react";
import Footer from "./components/Footer";
import Header from "./components/Header";

const App = () => {
  const [counter, setCounter] = useState(0);
  const title = "Building Counter App";

  const doPlus = () => {
    setCounter(counter + 1);
    console.log("Counter is ", counter);
  };

  const doMinus = () => {
    setCounter(counter - 1);
    console.log("Counter is ", counter);
  };
  return (
    <div>
      <Header />
      <h1>
        {title} Value is {counter}
      </h1>
      <button onClick={doPlus}>Plus</button>
      <button onClick={doMinus}>Minus</button>
      <Footer />
    </div>
  );
};
export default App;
