const Footer = () => {
  return <h1>Develop By : </h1>;
};
export default Footer;
