const Header = () => {
  return <h1>Counter App</h1>;
};
export default Header;
