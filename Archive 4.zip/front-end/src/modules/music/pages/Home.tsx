

export const Home = () => {
  return (
    <div>
        <h1>Music Load Here</h1>
    </div>
  )
}
