// glue b/w view and model / service
import { validateName } from "./validation.js"; 
import todoOperations from "./service.js";
window.addEventListener('load', bindEvents);
function bindEvents(){
document.getElementById('add').addEventListener('click', addTask);
}
function addTask(){
    var task = readFields();
    if(verifyFields(task)){
        todoOperations.addTask(task);
        printTask(task);
    }

    //console.log('Task is ', task);

}

function printTask(task){
    const tbody = document.querySelector('#task-list');
   // const str = `<tr> <td>`;
   const tr = tbody.insertRow();
   //tr.insertCell(0).innerText = 1001;
   let index = 0;
   for(let key in task){
        tr.insertCell(index).innerText = task[key];
        index++;
   }

}

function verifyFields(task){
    var errorMessage = "";
    errorMessage = validateName(task.name);
    if(errorMessage){
    document.getElementById('name-error').innerText  = errorMessage;
    return false;
    }
   
        return true;
    
}

function readFields(){
    // read the fields
    // var id = document.getElementById('id').value;
    // var name = document.getElementById('name').value;
    const FIELDS = ['id', 'name', 'desc' , 'date','time','photo'];
    var task = {};
    for(let field of FIELDS){
        task[field] = document.getElementById(field).value;
    }
    return task;
}