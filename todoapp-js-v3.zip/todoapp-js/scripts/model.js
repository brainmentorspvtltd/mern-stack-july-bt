// Model = Data
// Id , name , desc , photo etc