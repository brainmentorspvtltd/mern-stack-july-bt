import fs from 'fs';
export const getAllSongs = (req, res)=>{
    res.json({message:'Get All Songs '});
}
export const searchSongs = (req, res)=>{
    res.json({message:'Search Songs '});
}
export const addSong = (req, res)=>{
    console.log('I am in Add Song ', req.body); // data 
     console.log('Add songs ' , req.files); // file 
     const fileName = req.files.file.name;
     const data = req.files.file.data;
     fs.writeFileSync('/Users/amitsrivastava/Documents/music-app/back-end/upload/'+fileName, data)
     // bytes of stream and then write in a file
    res.json({message:'Add Song '});
}

export const updateSong = (req, res)=>{
    res.json({message:'Update Song '});
}