export const getAllSongs = (req, res)=>{
    res.json({message:'Get All Songs '});
}
export const searchSongs = (req, res)=>{
    res.json({message:'Search Songs '});
}
export const addSong = (req, res)=>{
    res.json({message:'Add Song '});
}

export const updateSong = (req, res)=>{
    res.json({message:'Update Song '});
}