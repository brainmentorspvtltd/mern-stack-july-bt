import { UserModel } from "../models/user-model.js";
import { encryptPassword } from "../utils/services/password-hash.js";

export const register = async (userObject)=>{
    try{
        userObject.password = encryptPassword(userObject.password);
    const doc = await UserModel.create(userObject);
    if(doc && doc._id){
        return "User Register SuccessFully";
    }
}
catch(err){
    throw err;
}
}