import axios from 'axios';
import { data } from 'react-router-dom';
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
axios.defaults.baseURL =  API_BASE_URL;
export const doRegister = (userData:unknown)=>{
    
    return axios.post('register', {data:userData}); // Promise
}