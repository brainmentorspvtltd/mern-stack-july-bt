1. Add feature

a) button click ?
When I click on a button it must call some function , and this function contains the add logic.

Button - source

Click - event

Action - function(){}

2. When add function calls , it do the following
   2.1
   a) read the fields
   b) validate the fields , if validation is correct so it will store the value
   Id , name, desc, photo , date, time - so it means it is an object.
   Object = record
   I need multiple records (task) so it means array of objects

2.2 now print the record (object). e.g for in loop dynamically tr and td build

2.3 show the totals , array length
